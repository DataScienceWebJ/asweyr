export default function GeneratorForm() {
  return (
    <div className="max-w-2xl mx-auto px-4 mt-10">
      <h2 className="text-xl font-semibold mb-4">Генератор текста</h2>
      <textarea className="w-full border p-2 rounded mb-4" placeholder="Введите тему..."></textarea>
      <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Сгенерировать</button>
    </div>
  );
}
