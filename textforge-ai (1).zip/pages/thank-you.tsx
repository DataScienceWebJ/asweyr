import { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function ThankYou() {
  const router = useRouter();

  useEffect(() => {
    document.cookie = "paidAccess=true; path=/; max-age=86400"; // 1 день
    setTimeout(() => {
      router.push('/');
    }, 2000);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-2xl font-bold">Спасибо за оплату! Перенаправляем...</h1>
    </div>
  );
}
