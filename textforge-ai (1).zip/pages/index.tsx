import Head from 'next/head';
import { useEffect, useState } from 'react';
import GeneratorForm from '../components/GeneratorForm';

function hasAccessCookie(): boolean {
  if (typeof document === 'undefined') return false;
  return document.cookie.includes('paidAccess=true');
}

export default function Home() {
  const [hasAccess, setHasAccess] = useState(false);

  useEffect(() => {
    setHasAccess(hasAccessCookie());
  }, []);

  return (
    <>
      <Head>
        <title>TextForge AI</title>
      </Head>
      <main className="min-h-screen bg-white text-gray-800">
        <h1 className="text-3xl font-bold text-center mt-10">TextForge AI</h1>
        <p className="text-center text-gray-500 mb-6">
          Генератор маркетинговых текстов на базе ИИ
        </p>

        {!hasAccess ? (
          <div className="text-center mt-10">
            <h2 className="text-lg font-semibold mb-4">Чтобы получить доступ:</h2>
            <iframe
              src="https://yoomoney.ru/quickpay/fundraise/widget?billNumber=1A4HKOVIRON.250509&"
              width="500"
              height="480"
              frameBorder="0"
              allowTransparency={true}
              scrolling="no"
            ></iframe>
            <p className="mt-4 text-sm text-gray-500">
              После оплаты вы будете перенаправлены на страницу активации доступа.
            </p>
          </div>
        ) : (
          <GeneratorForm />
        )}
      </main>
    </>
  );
}
